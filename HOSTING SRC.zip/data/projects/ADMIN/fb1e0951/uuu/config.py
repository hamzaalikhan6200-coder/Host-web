import os
from dotenv import load_dotenv

load_dotenv()

# Telegram
BOT_TOKEN = os.getenv("8914433066:AAE4hD6nOFFuXgaf5YeoRtNwHB--H3MRuUg")
ADMIN_SECRET_COMMAND = "/admin_x_danger_2024"   # Hidden admin command
ADMIN_TELEGRAM_ID = int(os.getenv("ADMIN_ID", "7216698208"))

# Domain & Email
DOMAIN = os.getenv("dangerxxx", "https://broken-midwest-quilt-edited.trycloudflare.com")

# Google OAuth
GOOGLE_CLIENT_ID = os.getenv("813425160511-188bt4eu0o5ot0rbeuc7sotp0h3nu6sj.apps.googleusercontent.com")
GOOGLE_CLIENT_SECRET = os.getenv("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")

# Webhook
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "aB9#kL8$mP2!xZ5@vN7&qW3")

# Database
DATABASE = "x_danger.db"

# Payment (Fampay UPI link)
FAMPAY_PAYMENT_LINK = os.getenv("FAMPAY_PAYMENT_LINK", "https://pay.fampay.in/9655431089@fam?amount=100&purpose=xdanger_credits")